module.exports = {
        publicPath: "./",
	devServer: {
	   disableHostCheck: true
	}
    };